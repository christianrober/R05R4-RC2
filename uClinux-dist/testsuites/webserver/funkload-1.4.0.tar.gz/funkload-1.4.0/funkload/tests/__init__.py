"""FunkLoad test package.

$Id: __init__.py 30338 2005-12-06 10:20:56Z bdelbosc $
"""
